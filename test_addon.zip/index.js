"use strict"

const tabs = require("sdk/tabs");
const self = require("sdk/self");
const io = require("sdk/io/file");
const pageMod = require("sdk/page-mod");
const path = require("sdk/fs/path");
var url = require("sdk/url");
var utils = require('sdk/window/utils');
var Request = require("sdk/request").Request;
var system = require("sdk/system");
var preferences = require("sdk/simple-prefs").prefs;

const {Cc ,Ci , Cu, CC } = require('chrome');
Cu.import("resource://gre/modules/Downloads.jsm");
Cu.import("resource://gre/modules/osfile.jsm")
Cu.import("resource://gre/modules/Task.jsm");
Cu.import("resource://gre/modules/FileUtils.jsm");


var nsIFilePicker = Ci.nsIFilePicker;
var fp = Cc["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
var parser = Cc["@mozilla.org/xmlextras/domparser;1"].createInstance(Ci.nsIDOMParser);


var group_download_dir = Cc["@mozilla.org/file/local;1"]
           .createInstance(Ci.nsILocalFile);

pageMod.PageMod({
  include: "*.vk.com",
  contentStyleFile: self.data.url("tooltip.css"),
  contentScriptFile: self.data.url("content.js"),
  contentScriptWhen:"start",
  onAttach: worker =>{

    require("sdk/simple-prefs").on("show_bitrate", function(pref_name){
      worker.port.emit("do_show_bitrate", preferences["show_bitrate"]);
    })

    worker.port.on("download_all", info => {

     if (!preferences["show_dialog"]){

        let dir = make_download_path("group");

        info.forEach( info_item => {
           download_track(info_item.id,
                          info_item.remixsid,
                          info_item.filename,
                          dir);
        });
     }else{
         let browserWindow = utils.getMostRecentBrowserWindow();
         let window = browserWindow.content;
         fp.init(utils.getToplevelWindow(window), "Select a File", nsIFilePicker.modeGetFolder);

         let init_dir = make_download_path("group");

         if (init_dir){
            group_download_dir.initWithPath(init_dir);
            fp.displayDirectory = group_download_dir;
         }

         let rv = fp.show();

         if (rv == nsIFilePicker.returnOK || rv == nsIFilePicker.returnReplace) {
           let dir = fp.file.path;

            info.forEach( info_item => {
              download_track(info_item.id,
                             info_item.remixsid,
                             info_item.filename,
                             dir);
            });
         }
     }

    });

    worker.port.on("download_track", info => {
      let dir = make_download_path("single");

      download_track(info.id,
                     info.remixsid,
                     info.filename,
                     dir);
    });

    worker.port.on("get_bitrate", info => {
      get_bitrate(info, worker);
    });

    worker.port.on("initialize_show_bitrate", () => {
      worker.port.emit("do_show_bitrate", preferences["show_bitrate"]);
    });

  }
});


function download_track(id, remixsid, filename, dir) {

  Request({
    url:"https://vk.com/al_audio.php",
    headers:{Host:"vk.com", Cookie: remixsid},
    content:{act:'reload_audio', ids:id + "," + id, al:"1"},
    onComplete: response => {
      let content = response.text;
      let jstr = content.substring(content.indexOf("[["),
                                  content.indexOf("]]<!>")+2);
      let parsed = JSON.parse(jstr);
      let url = parsed[0][2];
      filename = fix_filename(filename);

      Task.spawn(function () {
        let list = yield Downloads.getList(Downloads.ALL);

        let download = yield Downloads.createDownload({
          source: url,
          target: io.join(dir, filename),
        });
        list.add(download);
        download.start();

      }).then(null, function(){console.log("Download file error");});
    }
  }).post();
}


function fix_filename(filename){
  if(system.platform == "winnt"){
    filename=filename.replace(/[<>/*?:\\|"]/g, "");
  }else{
    filename = filename.replace(/\//g, "");
  }
  return filename;
}

function make_download_path(mode){

    let dir = "";

    if(mode == "single"){
        dir = preferences["single_download_dir"];
    }else{
       dir = preferences["group_download_dir"];
       if (!dir){
          dir = preferences["single_download_dir"];
       }
    }

    if (!dir)
       dir = FileUtils.getDir("DfltDwnld", []).path;

    if( !io.exists(dir))
        io.mkpath(dir);

    return dir;
}



function get_bitrate(info, worker) {

  Request({
    url:"https://vk.com/al_audio.php",
    headers:{Host:"vk.com", Cookie: info["remixsid"]},
    content:{act:'reload_audio', ids:info["id"] + "," + info["id"], al:"1"},
    onComplete: response => {
      let content = response.text;
      let jstr = content.substring(content.indexOf("[["),
                                  content.indexOf("]]<!>")+2);
      let parsed="";
      try{
          parsed = JSON.parse(jstr);
      }catch(err){
        console.log(err.name + "\n" + content);
        return;
      }

      let url = parsed[0][2];
      let duration = info["duration"];
      Request({
        url:url,
        onComplete: response => {
          let size = response.headers['Content-Length'];//get file size
          let kbit=size/128;//calculate bytes to kbit
          let bitrate= Math.ceil(Math.round(kbit/duration)/16)*16;
          worker.port.emit("yourBitrateSir", {id:info["id"], bitrate:bitrate});

        }
      }).head();
    }
  }).post();

}
